package com.example.imple.salgrade.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Salgrade {
	int grade;
	Integer losal;
	Integer hisal;
}
