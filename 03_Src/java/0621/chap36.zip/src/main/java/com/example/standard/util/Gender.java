package com.example.standard.util;

public enum Gender {
	M, F
}
