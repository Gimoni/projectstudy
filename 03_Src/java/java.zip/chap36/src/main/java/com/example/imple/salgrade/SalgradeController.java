package com.example.imple.salgrade;

public class SalgradeController {

}
